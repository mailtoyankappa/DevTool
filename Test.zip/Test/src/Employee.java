
public class Employee {

	private String name;
    private int salary;
    private int id;
	public String getName() {
		return name;		
	}
	public Employee(int salary, String name, int id) {
		super();
		this.name = name;
		this.salary = salary;
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Override
    public int hashCode() {
       System.out.println("In hashcode"+this.getId());
      return this.getId();
    }
 
	@Override
    public boolean equals(Object obj) {
	Employee e = null;
        if(obj instanceof Employee){
	        e = (Employee) obj;
        }
        System.out.println("In equals Venky"+this.getId());
        if(this.getId() == e.getId()){
	        return true;
        } else {
	        return false;
        }  
     }
	public int compare(Employee o1, Employee o2) {
	return o1.getName().compareTo(o2.getName());
	}
	
}

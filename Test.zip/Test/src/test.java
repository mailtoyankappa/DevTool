
public interface test {

	default void method(){
		System.out.println("print elements from test Interface");
	}
	static void method1(){
		System.out.println("print elements from test Interface");
	}
}

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class removeListElement {
	// static public removeListElement(){}
	public static void main(String args[]) {
		System.out.println("enter the list");
		List<Integer> nums = new ArrayList<>();
		List<String> stlist = new ArrayList<>();
		stlist.add("a");
		stlist.add("c");
		stlist.add("d");
		stlist.add("e");
		stlist.add("b");
		stlist.add("a");
		stlist.add("b");
		stlist.add("f");
		nums.add(1);
		nums.add(2);
		nums.add(3);
		nums.add(5);
		nums.add(6);
		nums.add(7);
		nums.add(8);
		nums.add(3);
		nums.add(5);
		nums.add(6);
		List<Integer> filteredList = nums.stream().filter(i -> i > 3)
				.collect(Collectors.toList());
		int sum = nums.stream().collect(
				Collectors.summingInt(Integer::intValue));
		int sum1 = nums.stream().mapToInt(Integer::intValue).sum();
		System.out.println("Print the Element :" + sum + " s " + sum1);
		System.out.println("list : " + filteredList);
		Long number = nums.stream().filter(i -> i % 2 == 0)
				.filter(i -> i % 10 == 0).count();
		List<Integer> dist = nums.stream().distinct()
				.collect(Collectors.toList());
		List<String> l = stlist.stream().distinct()
				.collect(Collectors.toList());
		System.out.println("list : " + l);
		int max = nums.stream().max(Integer::compare).get();
		int min = nums.stream().min(Integer::compare).get();
		System.out.println("Max in list: " + max);
		System.out.println("Min in list: " + min);
		System.out.println("Even list: " + number);
		System.out.println("dist list: " + dist);

		final Map<String, Integer> wordCounts = new HashMap<>();
		wordCounts.put("USA", 100);
		wordCounts.put("jobs", 200);
		wordCounts.put("software", 50);
		wordCounts.put("technology", 70);
		wordCounts.put("opportunity", 200);

		Map<String, Integer> sort = wordCounts
				.entrySet()
				.stream()
				.sorted(Map.Entry.comparingByValue())
				.collect(
						Collectors.toMap(Map.Entry::getKey,
								Map.Entry::getValue, (i, j) -> i,
								LinkedHashMap::new));
		System.out.println("print :");
		Map<String, Integer> srt = wordCounts
				.entrySet()
				.stream()
				.sorted(Map.Entry.comparingByValue())
				.collect(
						Collectors.toMap(Map.Entry::getKey,
								Map.Entry::getValue, (i, j) -> i,
								LinkedHashMap::new));
		// Map<String, Integer> sort =
		// wordCounts.entrySet().stream().sorted(Map.Entry.<String,
		// Integer>comparingByValue().reversed()).collect(Collectors.toMap(Map.Entry::getKey,
		// Map.Entry::getValue,(i,j)->i,LinkedHashMap :: new));
		System.out.println("map :" + sort);
		Scanner in = new Scanner(System.in);
		System.out.println("ENter the STring Word :");
		String str = in.nextLine();
		// str = str.replaceAll(arg0, arg1);
		System.out.println("string after replacing in splm char :" + str);
		int len = str.length() - 1, i = 0;
		char[] ch = str.toCharArray();
		while (i < len) {
			if (!Character.isAlphabetic(ch[len])) {
				len--;
			} else if (!Character.isAlphabetic(ch[i])) {
				i++;
			} else {
				char temp = ch[i];
				ch[i] = ch[len];
				ch[len] = temp;
				len--;
				i++;
			}
		}

		String result = new String(ch);
		System.out.println("after reversing string : " + result);
		removeListElement obj = new removeListElement();
		String s1 = removeListElement.recrevStr(str);
		System.out.println("using recursion :" + s1);
		System.out
				.println("enter the string which is in list and return the string : ");
		String line = in.nextLine();
		String linearray[] = line.split(" ");
		String s = "";
		String fin = "";
		System.out.println("print len " + linearray.length);
		for (int j = 0; j < linearray.length; j++) {
			fin = obj.returnString(linearray[j].toString());
			System.out.println("Print the STring: " + fin);
			s = s + " " + fin;
		}
		System.out
				.println("final String after reversing without affecting spl char :"
						+ s);
	}

	public String returnString(String str) {
		int len = str.length() - 1, i = 0;
		char[] ch = str.toCharArray();
		while (i < len) {
			if (!Character.isAlphabetic(ch[len])) {
				len--;
			} else if (!Character.isAlphabetic(ch[i])) {
				i++;
			} else {
				char temp = ch[i];
				ch[i] = ch[len];
				ch[len] = temp;
				len--;
				i++;
			}
		}

		return str = new String(ch);
	}

	public static String recrevStr(String str1) {
		if (str1.isEmpty()) {
			return str1;
		}
		// Calling function recursively
		return recrevStr(str1.substring(1)) + str1.charAt(0);
	}
}

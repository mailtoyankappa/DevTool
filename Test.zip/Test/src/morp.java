import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class morp extends poly {
	String method(String name) {
		System.out.println("Method inside without Param Child " + name);
		ArrayList<Object> l1 = new ArrayList<>();
		l1.add(1);
		l1.add("Venky");
		List<Integer> list = new ArrayList<>();
		list.add(9);
		list.add(3);
		list.add(7);
		list.add(5);
		list.add(-3);
		list.add(-7);
		System.out.println("print :"
				+ list.parallelStream().filter(e -> e > 0).count());
		ArrayList<Integer> l = (ArrayList<Integer>) list.stream()
				.filter(i -> i > 0).sorted().collect(Collectors.toList());
		long i = list.stream().min(Integer::compare).get();
		System.out.println("Print :" + l + " " + i);
		return name;
	}

	public static void main(String[] args) {
		morp m = new morp();
		m.method("Venky");
		Veriables v = new Veriables();
		v.method();
	}
}

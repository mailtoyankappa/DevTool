import javax.crypto.spec.GCMParameterSpec;


public class Veriables {	
	String name;
	static String LastName;	
	
	void method(){
		String MName="T";
		name="Venky";
		LastName="Kuri";			
		System.out.println("print :"+name+MName+LastName);
	}
	void method1(String name){
		String MName="T";
		//name="Venky";// Based on Object it will change its value.
		//LastName="Kuri";// Class Variable will fetch from the Method(), But instance Variable wont share each 		
		System.out.println("print :"+name+MName+LastName);
	}
	public static void main(String[] args) throws Throwable {		
		Veriables v = new Veriables();
		Veriables v1 = new Veriables();	
		String s = new String("abc");		
		System.out.println("print :"+s);
		//s = null;
		System.gc();
		System.out.println("print :"+s);
		v.method();
		v1.method1("Sachin");
		v.finalize();
	}
}

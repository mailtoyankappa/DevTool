import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class ClinkedList {
	  private static String filepath = "C:\\Users\\nikos\\Desktop\\TestFiles\\testFile2.txt";
	  public static void main(String args[]){
		  ClinkedList l = new ClinkedList();
		  l.method();
	  }
	  public void method(){
		
		  BufferedReader br = null;
	        String curline;
	        try {
	            br = new BufferedReader(new FileReader(filepath));
	            while ((curline = br.readLine()) != null) {
	                System.out.println(curline);
	            }
	        } catch (IOException e) {	         
	            System.err.println("An IOException was caught :"+e.getMessage());
	            callmethod();
	        }finally{
	             
	            //try {
	                 
	                if(br != null);
	                    //br.close();
	             
	           /* } catch (IOException e) {
	                 
	                e.printStackTrace();
	            }*/
	        }
	 
	    } 
	  public void callmethod(){
		  try {
	           BufferedReader br1 = new BufferedReader(new FileReader(filepath));
	 
	            Object curline = null;
				//while ((curline = br1.readLine()) != null) {
	                System.out.println(curline);
	            //}
	 
	        }
		  catch(FileNotFoundException e){
              System.out.println("The source file does not exist. " + e);
            }        
	  }
	  }
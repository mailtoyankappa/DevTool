
public class Alist {

	public static void main(String[] args) {
		

	}

}

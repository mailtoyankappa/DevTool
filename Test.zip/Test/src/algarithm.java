import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


public class algarithm {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Entere the Base element");
		int base = in.nextInt();
		System.out.println("Enter the exponant");
		int exponent = in.nextInt();
        long result = 1;
        while (exponent != 0)
        {
            result *= base;
            exponent--;
        }
        System.out.println("Answer = " + result);
        System.out.println("enter the length array");
        int n = in.nextInt();
        int a[] = new int[n+1];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n; i++)
        {
            a[i] = in.nextInt();
        }
        List l1 = Arrays.asList(a);
        List<Integer> l = new ArrayList<>();
      }
	
}


public interface test1 {

	default void method(){
		System.out.println("print elements from test1 Interface");
	}
}

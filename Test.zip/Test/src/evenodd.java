import java.util.Scanner;

public class evenodd {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		try {
		//AsyncClientHttpRequestFactory
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the first String :");
		String txt = in.nextLine();
		@SuppressWarnings("unused")
		int number = Integer.parseInt(txt);
		char[] numbers = txt.toCharArray();
		String result = "";
		for (int i = 1; i < numbers.length; i++) {
			int m = Character.getNumericValue(numbers[i - 1]);
			int n = Character.getNumericValue(numbers[i]);
			result += m;
			if (m % 2 == 0 && n % 2 == 0) {
				result += "*";
			}else if(m % 2 != 0 && n % 2 != 0){
				result += "-";
			}else {
				//do nothing
			}
		}
		result += numbers[numbers.length - 1];
		System.out.println(result);
		 }
        catch (NumberFormatException nfe) {
            System.out.println("Engter the Numbers Only");
        }
	}

}
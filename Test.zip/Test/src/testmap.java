import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;


public class testmap {

	public static void main(String args[]){
		HashMap<Employee, String> hashMap = new HashMap<Employee, String>();
		
		Employee t = new Employee(20, "Venky", 8000);
		Employee t1 = new Employee(21, "SVenky", 8000);
		Employee t2 = new Employee(19, "MVenky", 8000);
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(t);
		list.add(t1);list.add(t2);
		
		hashMap.put(t, "VENKY");
		hashMap.put(t1, "VENKY");
		/*hashMap.put(new Employee(1,"Jai",50000), "JAI");
		hashMap.put(new Employee(1,"Jai",50000), "JAI");
		hashMap.put(new Employee(2,"Mahesh",80000), "MAHSESH");
		hashMap.put(new Employee(3,"Vishal",60000), "VISHAL");
		hashMap.put(new Employee(4,"Hemant",64000), "HEMANT");
		//hashMap.put(new Employee( (Integer) null,"Venky",64000), "Venky");
		System.out.println("HashMap elements:");*/
		Set<Employee> keys = hashMap.keySet();
		System.out.println("length "+hashMap.size());
	        for(Employee p:keys){
	            System.out.println(p+"-"+hashMap.get(p));
	        }
		//System.out.println("Add duplicate record:");
		//hashMap.put(new Employee(4,"Hemant",64000), "HEMANT");
		//System.out.println("HashMap elements:");
		keys = hashMap.keySet();
	        for(Employee p:keys){
	            System.out.println(p+"-"+hashMap.get(p));
	        }
	  }
}

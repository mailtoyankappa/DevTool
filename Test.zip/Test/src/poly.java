
public class poly {

  void method(){
		System.out.println("Method inside without Param");
	}
  void method(float name){
		System.out.println("Method inside without Param");
	}
  void method(double name){
		System.out.println("Method inside without Param");
	}
  String method(String name){
	  System.out.println("Method inside without Param "+name);
	  return name;
 	}
  int method(int name){
	  System.out.println("Method inside without Param "+name);
	  return name;
 	}
	
	public static void main(String[] args) {
	poly p = new poly();
	p.method();
	p.method("Venky");
	}

}

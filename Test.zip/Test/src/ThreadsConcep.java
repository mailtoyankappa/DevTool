

public class ThreadsConcep extends Thread{

	public void run(){
		System.out.println("thread Running Status");
	    
	}
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		Thread t = new Thread();
		System.out.println("Current State of thread before start:"+t.getState());
		t.start(); 
		System.out.println("Current State of thread: after start"+t.getState());
		try {
			t.sleep(1000);
			System.out.println("Current State of thread: after waiting"+t.getState());
			t.notifyAll();
			System.out.println("Current State of thread: after Notify: "+t.getState());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}

}

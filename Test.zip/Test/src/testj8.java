
public class testj8 implements test,test1{

	public void method(){		
			System.out.println("print elements from test class");		
	}	
	public static void main(String[] args) {
		testj8 t = new testj8();
		t.method();
		test.method1();
	}

}

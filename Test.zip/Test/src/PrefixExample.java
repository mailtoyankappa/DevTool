import java.util.Scanner;

public class PrefixExample {
	static String printLCSubStr(String X, String Y) {
		int m = X.length();
		int n = Y.length();
		int[][] temp = new int[m + 1][n + 1];
		int len = 0;
		int row = 0, col = 0;
		for (int i = 0; i <= m; i++) {
			for (int j = 0; j <= n; j++) {
				if (i == 0 || j == 0)
					temp[i][j] = 0;

				else if (X.charAt(i - 1) == Y.charAt(j - 1)) {
					temp[i][j] = temp[i - 1][j - 1] + 1;
					if (len < temp[i][j]) {
						len = temp[i][j];
						row = i;
						col = j;
					}
				} else
					temp[i][j] = 0;
			}
		}

		if (len == 0) {
			System.out.println("No Common Substring");
			return null;
		}
		String resultStr = "";

		while (temp[row][col] != 0) {
			resultStr = X.charAt(row - 1) + resultStr;
			--len;
			row--;
			col--;
		}
		System.out.println(resultStr);
		return resultStr;
	}

	@SuppressWarnings("resource")
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the first String :");
		String txt = in.nextLine();
		System.out.println("Enter the Second String :");
		String pat = in.nextLine();
		String str = printLCSubStr(txt, pat);
		System.out.println("Prefix String is : "+str);
	}
}
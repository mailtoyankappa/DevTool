import java.util.Vector;

class ABC {

	static void originalArray(int greater[], int n) {
		Vector<Integer> temp = new Vector<Integer>();
		for (int i = 0; i <= n; i++)
			temp.add(i);
		int arr[] = new int[n];
		for (int i = 0; i < n; i++) {
			int len = greater[i];
			System.out.println("print :" + len);
			int k = n - greater[i] - i;
			arr[i] = temp.get(k);
			temp.remove(k);
		}

		for (int i = 0; i < n; i++)
			System.out.print(arr[i] + " ");
	}

	// Driver code
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		int Arr[] = { 6, 3, 2, 1, 0, 1, 0 };
		int n = Arr.length;
		ABC d = new ABC();
		d.originalArray(Arr, n);
	}
}

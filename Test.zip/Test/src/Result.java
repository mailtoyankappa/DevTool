import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;



class Result {
	public static <T, U> List<U> 
    convertIntListToStringList(int[] arr, Function<T, U> function) 
    { 
        return null;//arr.stream().map(function).collect(Collectors.toList()); 
    } 
    public static List<String> getShrunkArray(List<String> inputArray, int burstLength) {
        int n = burstLength;
       String[] greater = new String[inputArray.size()];
       greater = inputArray.toArray(greater);
       Vector<Integer> temp = new Vector<Integer>();  
    for (int i = 0; i <= n; i++)  
        temp.add(i);  
  
    int[] arr = new int[n];  
    for (int i = 0; i < n; i++) 
    {  
        String len = greater[i];
        System.out.println("Print :"+len);
        int x = Integer.parseInt(len);
        int k = n - x - i;  
        arr[i] = temp.get(k);  
        temp.remove(k);  
    }  
    for (int i = 0; i < n; i++)  
            System.out.print(arr[i] + " ");
    List<String> listOfString = convertIntListToStringList(arr, s -> String.valueOf(s)); 
    return listOfString;
}  
    
    @SuppressWarnings("static-access")
	public static void main(String[] args) {
		int Arr[] = { 6, 3, 2, 1, 0, 1, 0 };
		int n = Arr.length;
		ABC d = new ABC();
		d.originalArray(Arr, n);
	}
}
